package com.example.dodolandigital;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    CheckBox netflix,spo,yt;
    Button tumbas;
    TextView tampil;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        netflix=(CheckBox)findViewById(R.id.netflix);
        spo=(CheckBox)findViewById(R.id.spo);
        yt=(CheckBox)findViewById(R.id.yt);
        tumbas=(Button)findViewById(R.id.tumbas);
        tampil=(TextView)findViewById(R.id.tampil);
        tumbas.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // KONDISI GA ADA YANG BELI
                if (!netflix.isChecked() && !spo.isChecked() && !yt.isChecked()) {
                    Toast.makeText(getApplicationContext(), "Kalau mau beli dicentang dulu gan", Toast.LENGTH_SHORT).show();
                } else {
                    String a = "";
                    if (netflix.isChecked()) {
                        a += "Netflix Seharga Rp. 50.000\n";
                    }
                    String b = "";
                    if (spo.isChecked()) {
                        b += "Spotify Seharga Rp. 30.000\n";
                    }
                    String c = "";
                    if (yt.isChecked()) {
                        c += "Youtube Seharga Rp. 20.000\n";
                    }
                    tampil.setText("Pesanan yang mau kamu beli adalah\n" + a + "" + b + "" + c);
            }
        }
        });
    }
}