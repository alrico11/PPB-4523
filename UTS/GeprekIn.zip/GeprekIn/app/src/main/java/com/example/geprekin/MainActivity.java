package com.example.geprekin;

import androidx.annotation.RequiresPermission;
import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.TextView;
import android.widget.Toast;

import com.example.geprekin.R;

public class MainActivity extends AppCompatActivity {
    CheckBox ayam,bebek,mie;
    Button tumbas;
    TextView tampil;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        ayam=(CheckBox)findViewById(R.id.ayam);
        bebek=(CheckBox)findViewById(R.id.bebek);
        mie=(CheckBox)findViewById(R.id.mie);
        tumbas=(Button)findViewById(R.id.tumbas);
        tampil=(TextView)findViewById(R.id.tampil);
        tumbas.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // KONDISI GA ADA YANG BELI
                if (!ayam.isChecked() && !bebek.isChecked() && !mie.isChecked()) {
                    Toast.makeText(getApplicationContext(), "Kalau mau beli dicentang dulu gan", Toast.LENGTH_SHORT).show();
                } else {
                    String a = "";
                    if (ayam.isChecked()) {
                        a += "Ayam Geprek In + Nasi + Es Teh Seharga Rp. 15.000\n";
                    }
                    String b = "";
                    if (bebek.isChecked()) {
                        b += "Bebek Geprek In + Nasi + Es Teh Seharga Rp. 30.000\n";
                    }
                    String c = "";
                    if (mie.isChecked()) {
                        c += "Mie Geprek In + Es Teh Seharga Rp. 10.000\n";
                    }
                    tampil.setText("Pesanan yang mau kamu beli adalah\n" + a + "" + b + "" + c);
                }
            }
        });
    }
}